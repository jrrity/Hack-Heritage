from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://127.0.0.1:27017")  # Update if using remote
db_name = "Envix"
survey_collection_name = "survey_data"
category_collection_name = "category"

db = client[db_name]

# Verify collections
if survey_collection_name not in db.list_collection_names():
    print(f"Collection '{survey_collection_name}' not found in database '{db_name}'.")
    exit()

survey_collection = db[survey_collection_name]
category_collection = db[category_collection_name]

# Count documents in survey_data
count = survey_collection.count_documents({})
if count == 0:
    print(f"No documents found in '{survey_collection_name}'. Nothing to copy.")
    exit()
else:
    print(f"Found {count} documents in '{survey_collection_name}'. Copying to '{category_collection_name}'...")

# Fetch all documents
survey_entries = list(survey_collection.find({}))

# Copy to category collection
copied_count = 0
for entry in survey_entries:
    entry.pop("_id", None)  # Remove _id to avoid duplicate key issues
    category_collection.insert_one(entry)
    copied_count += 1

print(f"Copied {copied_count} entries into '{category_collection_name}' collection successfully.")
