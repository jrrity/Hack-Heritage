import React, { useEffect, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix Leaflet marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: new URL("leaflet/dist/images/marker-icon-2x.png", import.meta.url).href,
  iconUrl: new URL("leaflet/dist/images/marker-icon.png", import.meta.url).href,
  shadowUrl: new URL("leaflet/dist/images/marker-shadow.png", import.meta.url).href,
});

// Helper: calculate centroid of points
const getCentroid = (points) => {
  let latSum = 0, lngSum = 0;
  points.forEach(p => {
    latSum += p.latitude;
    lngSum += p.longitude;
  });
  return {
    lat: latSum / points.length,
    lng: lngSum / points.length,
    count: points.length
  };
};

// Helper: group points within radius
const groupPoints = (points, radiusMeters) => {
  const clusters = [];
  const used = new Set();

  points.forEach((point, idx) => {
    if (used.has(idx)) return;
    const clusterPoints = [point];
    used.add(idx);

    points.forEach((other, jdx) => {
      if (used.has(jdx)) return;
      const dist = L.latLng(point.latitude, point.longitude)
        .distanceTo(L.latLng(other.latitude, other.longitude));
      if (dist <= radiusMeters) {
        clusterPoints.push(other);
        used.add(jdx);
      }
    });

    clusters.push(clusterPoints);
  });

  return clusters;
};

const MapView = ({ fullscreen }) => {
  const [map, setMap] = useState(null);
  const [mapData, setMapData] = useState([]);

  // Initialize map
  useEffect(() => {
    const mapInstance = L.map("map").setView([22.6, 88.35], 10);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© Envix",
      maxZoom: 19,
    }).addTo(mapInstance);
    setMap(mapInstance);

    return () => mapInstance.remove();
  }, []);

  // Fetch points
  useEffect(() => {
    fetch("http://127.0.0.1:5000/data")
      .then(res => res.json())
      .then(data => setMapData(data))
      .catch(err => console.error("Data fetch error:", err));
  }, []);

  // Render points and clusters
  useEffect(() => {
    if (!map || mapData.length === 0) return;

    let layers = [];

    const renderMap = () => {
      // Remove previous layers
      layers.forEach(layer => map.removeLayer(layer));
      layers = [];

      const zoom = map.getZoom();
      if (zoom < 13) return;

      const clusters = groupPoints(mapData, 750);

      clusters.forEach(clusterPoints => {
        if (clusterPoints.length < 3) {
          // Show individual points
          clusterPoints.forEach(p => {
            const marker = L.marker([p.latitude, p.longitude]).addTo(map);
            marker.bindPopup(`<b>Point</b><br>Lat: ${p.latitude}<br>Lng: ${p.longitude}`);
            const circle = L.circle([p.latitude, p.longitude], {
              radius: 200,
              color: "rgba(0,123,255,0.7)",
              fillColor: "rgba(0,123,255,0.3)",
              fillOpacity: 0.3
            }).addTo(map);
            layers.push(marker, circle);
          });
        } else {
          // Cluster marker
          const centroid = getCentroid(clusterPoints);
          const color = clusterPoints.length > 7 ? "red" : "orange";

          const clusterIcon = L.divIcon({
            html: `<div style="
              pointer-events: auto;
              background:${color};
              border-radius:50%;
              width:40px;
              height:40px;
              display:flex;
              align-items:center;
              justify-content:center;
              color:white;
              font-weight:bold;
              cursor: pointer;">
              ${clusterPoints.length}
            </div>`,
            className: "",
            iconSize: [40, 40]
          });

          const centroidMarker = L.marker([centroid.lat, centroid.lng], { icon: clusterIcon }).addTo(map);
          const clusterCircle = L.circle([centroid.lat, centroid.lng], {
            radius: 750,
            color: "rgba(255, 81, 0, 0.7)",
            fillColor: "rgba(255, 89, 0, 0.2)",
            fillOpacity: 0.3
          }).addTo(map);

          centroidMarker.bindPopup(`<b>Centroid</b><br>Size: ${centroid.count}<br>Lat: ${centroid.lat}<br>Lng: ${centroid.lng}`);

          layers.push(centroidMarker, clusterCircle);

          // Optional: show individual points inside cluster
          clusterPoints.forEach(p => {
            const innerMarker = L.marker([p.latitude, p.longitude]).addTo(map);
            innerMarker.bindPopup(`<b>Point</b><br>Lat: ${p.latitude.toFixed(6)}<br>Lng: ${p.longitude.toFixed(6)}`);
            const innerCircle = L.circle([p.latitude, p.longitude], {
              radius: 200,
              color: "rgba(0,123,255,0.7)",
              fillColor: "rgba(0,123,255,0.3)",
              fillOpacity: 0.3
            }).addTo(map);
            layers.push(innerMarker, innerCircle);
          });
        }
      });
    };

    map.on("zoomend", renderMap);
    renderMap();

    return () => {
      map.off("zoomend", renderMap);
      layers.forEach(layer => map.removeLayer(layer));
    };
  }, [map, mapData]);

  // Fix map rendering on fullscreen toggle
  useEffect(() => {
    if (map) {
      setTimeout(() => map.invalidateSize(), 300);
    }
  }, [fullscreen, map]);

  return <div id="map" style={{ width: "100%", height: "100%" }} />;
};

export default MapView;
